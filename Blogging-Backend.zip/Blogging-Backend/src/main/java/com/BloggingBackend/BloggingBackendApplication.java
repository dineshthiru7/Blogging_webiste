package com.BloggingBackend;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class BloggingBackendApplication {

	public static void main(String[] args) {
		SpringApplication.run(BloggingBackendApplication.class, args);
	}

}
